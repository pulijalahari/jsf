package com.equifax.bootsfaces.portlet.bean;

import java.io.Serializable;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

@ManagedBean
@ViewScoped
public class Bean implements Serializable{
  private static final long serialVersionUID = -9000000399138619117L;
  private boolean enabled;

  public void toggle() {
      enabled = !enabled;
  }

  public boolean isEnabled() {
      return enabled;
  }
 
}
