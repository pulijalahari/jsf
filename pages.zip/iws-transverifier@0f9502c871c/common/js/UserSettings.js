(function($, win, doc, undefined) {
	"use strict";
	var UserSettings = (function() {
		function UserSettings () {
			var _this = this;
			var /* @protected */ BindEvents = function() {
				$("#userSettingsForm").on("submit", function(e) {
					e.preventDefault();
					// DUMMY SUBMIT ACTION, DO NOT USE AS-IS
					if (this.checkValidity()) {
						var url = {
							"self": doc.location.href,
							"test": "http://localhost:3000"
						};
						try {
							$.ajax({
								type: "post",
								url: url.test,
								data: $(e.target).serialize(),
								success: function(resp) {
									console.log(resp);
								},
								error: function(xhrError, resp) {
									console.log("Error: ", xhrError);
								}
							});
						} catch(e) {
							console.log("Caught Exception: ", e);
						}
					}
				});
				$("#changeUsrPwdForm").on("submit", function(e) {
					e.preventDefault();
					// DUMMY SUBMIT ACTION, DO NOT USE AS-IS
					if (this.checkValidity()) {
						var url = {
							"self": doc.location.href,
							"test": "http://localhost:3000"
						};
						try {
							$.ajax({
								type: "post",
								url: url.test,
								data: $(e.target).serialize(),
								success: function(resp) {
									console.log(resp);
								},
								error: function(xhrError, resp) {
									console.log("Error: ", xhrError);
								}
							});
						} catch(e) {
							console.log("Caught Exception: ", e);
						}
					}
				});
			};
			// fire initializer
			BindEvents();
			return _this;
		}
		return UserSettings;
	}());
	$(function() {
		win.UserSettings = new UserSettings();
	}());
}(jQuery, this, document));