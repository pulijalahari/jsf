(function($, win, doc, undefined) {
	"use strict";
	var NewEmployer = (function() {
		function NewEmployer() {
			var _this = this;
			_this.CustomFormValidity = win.CustomFormValidity;
			var /* @protected */ BindEvents = function() {
				$(function() {
					_this.AddIdKeysToFields($(".dynamic-fieldsets fieldset").eq(0));
				}());
				$(".dynamic-fieldsets .fieldsets-ctrl .add").on("click", function() {
					var $newFieldset = _this.AddFieldset().next();
					_this.AddIdKeysToFields($newFieldset);
					_this.UpdateHTMLFileList($newFieldset.find(".file-dropzone"), $newFieldset.find(".dropzone-input")[0].files);
					// Initialize TWB Popover feature for new fieldset
					$newFieldset.find("[data-toggle=\"popover\"]").popover();
				});
				$(".dynamic-fieldsets").on("click", ".fieldsets-ctrl .delete", function(e) {
					e.stopPropagation();
					_this.RemoveFieldset($(e.currentTarget).closest("fieldset"));
				});
				/**
				 * File upload, with drag & drop area
				 */
				// Browse button click action
				$(".multiple-dropzones").on("click", ".dropzone-area, .dropzone-browse", function(e) {
					e.preventDefault();
					e.stopPropagation();
					var $fileInput = $(e.currentTarget).closest(".file-dropzone").find(".dropzone-input");
					_this.SetInputTriggerProperty($fileInput[0], this);
					$fileInput.click();
				});
				// Update visible HTML file list upon changing file input
				$(".multiple-dropzones").on("change", ".dropzone-input", function(e) {
					// Try to prevent triggering in screen readers
					_this.ChangeInputFiles(e);
				});
				$(".multiple-dropzones").on("dragover", ".dropzone-area", function(e) {
					_this.ChangeDropEffect(e);
				});
				$(".multiple-dropzones").on("drop", ".dropzone-area", function(e) {
					var $fileInput = $(e.currentTarget).closest(".file-dropzone").find(".dropzone-input");
					_this.SetInputTriggerProperty($fileInput[0], this);
					_this.ChangeInputFiles.call(_this, e);
				});
				// Remove file button click action
				$(".multiple-dropzones").on("click", ".file-ctrl.delete", function(e) {
					_this.RemoveFromFileList(e);
				});
				// $("#manualVerificationForm :submit").off("click").on("click", function(e) {
				// 	e.preventDefault();
				// 	return false;
				// });
				// Submit Action
				$("#manualVerificationForm").off("submit").on("submit", function(e) {
					e.preventDefault();
					_this.PrepFileInputsForSubmit($(e.target));
					console.dir(this);
					this.checkValidity() && this.submit();
				});
			};

			// fire initializer
			BindEvents();
			return _this;
		}
		NewEmployer.prototype = {
			constructor: NewEmployer,
			AddIdKeysToFields: function($fieldset) {
				var fieldsetIdx = $("fieldset").index($fieldset);
				$fieldset.find(":input").each(function(idx) {
					if (this.id.length && this.name.length) {
						var fieldName = this.name.replace(/^\w+\[\]\[(\w+)\](\[\])?/, "$1");
						this.id = fieldName + "_" + fieldsetIdx + "_" + idx;
						$(this).closest(".form-group").find("label").attr("for", this.id);
					}
				});
			},
			AddFieldset: function() {
				var _this = this;
				// Return fieldset to be manipulated later
				return $(".dynamic-fieldsets fieldset").eq(-1).after(function() {
					var $newFieldset = $(this).clone();
					var $delButton = $("<div class=\"fieldsets-ctrl pull-right\"><button class=\"btn delete rounded-circle\" type=\"button\" title=\"Remove Employer\"><span class=\"far fa-trash-alt\" aria-hidden=\"true\"></span></button></div>");
					_this.ResetFields($newFieldset);
					$newFieldset.find(".fieldsets-ctrl").length === 0 && $newFieldset.prepend($delButton);
					return $newFieldset;
				});
			},
			RemoveFieldset: function($fieldset) {
				$fieldset.remove();
			},
			ResetFields: function($fieldset) {
				$fieldset.find(":input").filter(function() {
					return this.type === "select";
				}).val(function() {
					return $(this).children(":first-child");
				});
				$fieldset.find(":input").filter(":checked")
					.prop("checked", false);
				$fieldset.find(":input").filter(function() {
					return !this.checked || this.type !== "select";
				}).val("");
				$fieldset.find(":input").removeClass("iserror");
				$fieldset.find(".validity-msg").remove();
			},
			ChangeDropEffect: function(e) {
				var evt = e.originalEvent || e;
				evt.preventDefault();
				evt.stopPropagation();
				evt.dataTransfer.dropEffect = "copy";
			},
			ChangeInputFiles: function(e, replacementData) {
				var evt = e.originalEvent || e;
				replacementData = (replacementData !== undefined) ? replacementData : null;
				evt.preventDefault();
				evt.stopPropagation();
				var _this = this;
				var $dropZone = $(evt.target).closest(".file-dropzone");
				var fileInput = $dropZone.find(".dropzone-input")[0];
				/**
				 * If file dialog was triggered by clicking
				 * an element other than file input button,
				 * use custom filelist property, then reset
				 * "triggeredByButton" property
				 */
				fileInput.formFiles = (fileInput.triggeredByButton !== undefined) ? ((fileInput.formFiles !== undefined) ? fileInput.formFiles : fileInput.files) : fileInput.files;
				fileInput.triggeredByButton = undefined;
				var fileStore;
				if (replacementData) {
					fileStore = replacementData;
				} else {
					var targetData = evt.dataTransfer || evt.target;
					fileStore = [];
					if (fileInput.formFiles.length) {
						[].push.apply(fileStore, fileInput.formFiles);
					}
					for (var i = 0; i < targetData.files.length; i++) {
						// Check if dragged file(s) already exists in FileList
						if (fileInput.formFiles.length) {
							var b = 0;
							for (var j = 0; j < fileInput.formFiles.length; j++) {
								if (JSON.stringify(file2Obj(targetData.files[i])) !== JSON.stringify(file2Obj(fileInput.formFiles[j]))) {
									b++;
								}
							}
							// Add file to Array if it doesn't exist already
							if (b === fileInput.formFiles.length) {
								fileStore.push(targetData.files[i]);
							}
						} else {
							fileStore.push(targetData.files[i]);
						}
					}
					(targetData.items !== undefined) && targetData.items.clear();
				}
				var fileList = fileStore.map(function(file) {return file;});
				fileList.__proto__ = Object.create(FileList.prototype);
				Object.defineProperty(fileInput, "formFiles", {
					value: fileList,
					writable: true,
				});
				_this.UpdateHTMLFileList($dropZone, fileInput.formFiles);
				// For file object comparison above
				function file2Obj(file) {
					return {
						"name": file.name,
						"lastModified": file.lastModified,
						"lastModifiedDate": file.lastModifiedDate,
						"size": file.size,
						"type": file.type,
						"webkitRelativePath": file.webkitRelativePath
					};
				}
			},
			RemoveFromFileList: function(e) {
				var _this = this;
				var evt = e.originalEvent || e;
				evt.preventDefault();
				evt.stopPropagation();
				var $dropZone = $(evt.target).closest(".file-dropzone");
				var fileInput = $dropZone.find(".dropzone-input")[0];
				var fileId = new Number($(evt.target).parent("li").attr("data-fileid"));
				var fileStore = [];
				if (fileInput.formFiles.length) {
					[].push.apply(fileStore, fileInput.formFiles);
				}
				fileStore.splice(fileId, 1);
				_this.ChangeInputFiles(e, fileStore);
			},
			UpdateHTMLFileList: function($dropZone, fileList) {
				var $htmlFileList = $dropZone.find(".dropzone-filelist");
				var $removeButton = $("<a href=\"#\" role=\"button\" class=\"file-ctrl delete\"></a>");
				var removeButtonText = $htmlFileList.attr("data-removebutton-text");
				$removeButton.attr("title", removeButtonText);
				$htmlFileList.find("li").length && $htmlFileList.find("li").remove();
				if (fileList.length) {
					$htmlFileList.append(function() {
						var listItems = [];
						for (var i = 0; i < fileList.length; i++) {
							listItems.push($("<li data-fileid=\"" + i +"\"></li>").html(fileList[i].name + $removeButton.prop("outerHTML")));
						}
						return listItems;
					});
				}
			},
			SetInputTriggerProperty: function(input, element) {
				Object.defineProperty(input, "triggeredByButton", {
					value: element,
					writable: true
				});
			},
			PrepFileInputsForSubmit: function($form) {
				$form.find("input:file").each(function() {
					var $this = $(this);
					if($this.val().length) {
						$this.val(null);
						if ($this.prop("formFiles").length) {
							Object.defineProperty($this[0], "files", {
								value: $this.prop("formFiles")
							});
						}
					}
				});
			}
		};
		return NewEmployer;
	}());
	win.NewEmployer = new NewEmployer();
}(jQuery, this, document));