(function($, win, doc, undefined) {
	"use strict";
	var NewOrder = (function() {
		function NewOrder () {
			var _this = this;
			var /* @protected */ BindEvents = function() {
				$("#newOrderForm").on("submit", function(e) {
						e.preventDefault();
						this.checkValidity() && this.submit();
					});
			};
			// fire initializer
			BindEvents();
			return _this;
		}
		return NewOrder;
	}());
	$(function() {
		win.NewOrder = new NewOrder();
	}());
}(jQuery, this, document));