(function($, win, doc, undefined) {
	'use strict';
	var SharedComponents = (function() {
		function SharedComponents () {
			this.init();
		}
		SharedComponents.prototype = {
			constructor: SharedComponents,
			init: function() {
				/****************
				 search inline
				*/
				$(".search-open").on("click", function () {
					{
						$(".search-inline").addClass("search-visible");
					}
				});
				$(".search-close").on("click", function () {
					$(".search-inline").removeClass("search-visible");
				});
				/**
				 * Back to Top button
				 */
				$(".btn-goto-top").off("click").on("click", function(e) {
					e.preventDefault();
					e.stopPropagation();
					if (win.scrollY > 0) {
						// win.scrollTo(null, 0);
						$("html, body").animate({
							scrollTop: null
						}, 1000);
					}
				});
				$(win).off("scroll").on("scroll", function(e) {
					if (e.currentTarget.scrollY > 0) {
						$(".btn-goto-top").fadeIn();
					}
					else {
						$(".btn-goto-top").fadeOut();
					}
				});
				/**
				*View More Button
				*/
				$("#moreDetails,#lessButton").toggle();
				$("#moreButton,#lessButton").off("click").click(function(){
					$("#moreDetails").toggle("slow","swing");
					$("#moreButton").toggle();
					$("#lessButton").toggle();
				});
				/**
				 * Modal events for Resources videos (html5)
				 */
				// $(".iws-video-modal.html-video").on("shown.bs.modal", function(e) {
				//     $(e.currentTarget).find(".vjs-has-started.vjs-paused video")[0].play();
				// });
				$(".iws-video-modal.html-video").on("hide.bs.modal", function(e) {
					if (LimelightPlayer !== undefined && $(e.currentTarget).find(".vjs-limelight-viewport > div").hasClass("vjs-has-started")) {
						$(e.currentTarget).find(".limelight-player")[0].doPause();
					} else { $(e.currentTarget).find("video")[0].pause(); }
				});
				/**
				*Contact Form autopopulate for choosenSolution
				*/
				var choosenSolution = window.location.hash.substr(1);
				if(choosenSolution) {
					$("#choosenSolution").val($("#" + choosenSolution).val());
				}
				
				/**
				*Contact Form Submission
				*/
				$("#contactForm").on("submit", function(event){
					event.preventDefault();
					var choosenSolution = $("#choosenSolution").val();
					
					if(choosenSolution === "Verifiers"){
						$("#dynamic_email").val("verifier-info@equifax.com");
					} else {
						$("#dynamic_email").val("moreinfo@equifax.com");
					}
					
					var data = $('#contactForm').serialize();
					var url = "https://mailengine.equifax.com/contactus";
					
					//testing purpose - needs to remove
					$("#dynamic_email").val("akbarsha.abduljabbar@equifax.com");
					data = $('#contactForm').serialize();
					url = "http://awbp1lc9a007.app.c9.equifax.com:3010/contactus";
					//end
					
					$(".contact-form .success, .contact-form .error").hide();
					
					$.ajax({
						url: url,
						type: 'post',
						data: data,
						success: function(msg) {
							$(".contact-form").hide();
							$(".contact-section .success").show();
							$('html, body').animate({
								scrollTop: $(".contact-form .success").offset().top
							}, 500);
						},
						error: function(msg) {
							$(".contact-form .error").show();
							$('html, body').animate({
								scrollTop: $(".contact-form .error").offset().top
							}, 500);
						}
					});
				});
				/**
				 * Login Popover
				 */
				$(".login[data-toggle=\"popover\"]").popover({
					container: "body",
					html: true,
					placement: "bottom",
					trigger: "manual",
					content: this.LoginPopoverContent
				});
				$(".login[data-toggle=\"popover\"]").click(function(){
					$(this).popover("toggle");
				});
				$("body").click(function(e) {
					if(e.target.dataset.toggle !== "popover" && $(e.target).parents("[data-original-title]").length === 0 && $(e.target).parents(".popover.show").length === 0) {
						$(".popover").popover("hide");
					}
				});
				/*fancy form*/
				$(".fancy-input input").each(function(){
					if($(this).val() !== ''){
						$(this).prev("label").addClass('active');
					}
				});
				$(".fancy-input input").keydown(function(){
					$(this).prev("label").addClass('active');
				});
				$(".fancy-input input").keyup(function(){
					if($(this).val() === "") {
						$(this).prev("label").removeClass('active');
					}
				});
				$(".fancy-input input").blur(function(){
					if($(this).val() === "") {
						$(this).prev("label").removeClass('active');
					}
				});
				/**on load modal**/
				setTimeout(function () {
					if ($("#onloadModal").length) {
						$.magnificPopup.open({
							items: {
								src: "#onloadModal"
							},
							type: "inline"
						});
					}
				}, 1000);
				$(".close-action-btn").click(function(){
					$(".mfp-close").trigger("click");
				});
				$("a.print-icon").click(function(){
					window.print();
				});
			},
			LoginPopoverContent: function() {
				return $("#login_popover_content").html();
			}
		};
		return SharedComponents;
	}());
	window.SharedComponents = new SharedComponents();
}(jQuery, window, document));