(function($, win, doc, undefined) {
	"use strict";
	function PopoverTooltip() {
		$(function() {
			// initalize tooltips and popovers
			$("[data-toggle=\"popover\"]").popover();
			$("[data-toggle=\"tooltip\"]").tooltip();
		}());
	}
	win.PopoverTooltip = new PopoverTooltip();
}(jQuery, this, document));