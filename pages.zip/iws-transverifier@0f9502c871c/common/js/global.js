(function($, win, doc, undefined) {
	"use strict";
	var AppGlobal = (function() {
		function AppGlobal () {
			var _this = this;
			var /* @protected */ BindEvents = function() {
				$(function() {
					// initalize tooltips and popovers
					$("[data-toggle=\"popover\"]").popover();
					$("[data-toggle=\"tooltip\"]").tooltip();
				}());
				// Custom click action for "more info (?)" hover icons
				$("a.more-info[data-toggle=\"popover\"], a.more-info[data-toggle=\"tooltip\"]").click(function(e) {
					e.preventDefault();
					return true;
				});
			};
			// fire initializer
			BindEvents();
			return _this;
		}
		return AppGlobal;
	}());
	$(function() {
		win.AppGlobal = new AppGlobal();
	}());
}(jQuery, this, document));