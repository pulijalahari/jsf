(function($, win, doc, undefined) {
	"use strict";
	var CustomFormValidity = (function() {
		function CustomFormValidity () {
			var _this = this;
			var /* @protected */ BindEvents = function() {
				// show error on inputs on blur
				$("form.has-customvalidity")
					.on("blur", ":input:not(:button)", function() {
						_this.ShowInputErrorMsg($(this));
						_this.HideInputErrorMsg($(this));
					});
				// validate upon pressing "Enter"
				// or clicking "Submit" button
				$("form.has-customvalidity :submit")
					.off("click").on("click", function(e) {
						// _this.SubmitForm(e) && $(this).off("click").click();
						_this.SubmitForm(e);
					});
				// Form's custom submit action
				// $("form.has-customvalidity")
				// 	.on("submit", function(e) {
				// 		e.preventDefault();
				// 		this.checkValidity() && this.submit();
				// 	});
			};
			// fire initializer
			BindEvents();
			return _this;
		}
		CustomFormValidity.prototype.ValidateForm = function($form) {
			var $inputs = $form.find(":input");
			var totalValidInputs = 0;
			$inputs.each(function() {
				this.checkValidity() && totalValidInputs++;
			});
			return totalValidInputs === $inputs.length;
		};
		CustomFormValidity.prototype.SubmitForm = function(event) {
			event.preventDefault();
			var _this = this,
				$currentTarget = $(event.currentTarget),
				$form = $currentTarget.closest("form.has-customvalidity");
			if (_this.ValidateForm($form)) {
				fireSubmitEvent();
			} else {
				_this.ShowInputErrorMsg($form.find(":input:not(:button)"));
				return false;
			}
			function fireSubmitEvent() {
				var eventToFire;
				var eventType = "submit";
				if (typeof InputEvent !== "undefined") {
					eventToFire = new Event(eventType, {
						"bubbles": true,
						"cancelable": true
					});
				} else {
					eventToFire = doc.createEvent("event");
					eventToFire.initEvent(eventType, true, true);
				}
				$form[0].dispatchEvent(eventToFire);
			}
		};
		CustomFormValidity.prototype.ShowInputErrorMsg = function($input) {
			var sValidityMsgTemplate = "<div class=\"validity-msg invalid form-text\" aria-hidden=\"false\"></div>";
			var $invalidInp = $input.filter(function () {
				return !this.validity.valid;
			});
			var $formGroup = $invalidInp.closest(".form-group");
			$input.removeClass("iserror");
			$invalidInp.addClass("iserror");
			$formGroup.find(".validity-msg").text(function() {
				var $input = $(this).parent().find(":input:not(:button)");
				return $input[0].validationMessage;
			});
			$formGroup.not($formGroup.has(".validity-msg")).append(function() {
				var $input = $(this).find(":input:not(:button)");
				return $(sValidityMsgTemplate).text($input[0].validationMessage);
			});
		};
		CustomFormValidity.prototype.HideInputErrorMsg = function($input) {
			var $validInp = $input.filter(function() {
				return this.validity.valid;
			});
			$validInp.removeClass("iserror");
			$validInp.closest(".form-group")
				.find(".validity-msg").remove();
		};
		return CustomFormValidity;
	}());
	win.CustomFormValidity = new CustomFormValidity();
}(jQuery, this, document));